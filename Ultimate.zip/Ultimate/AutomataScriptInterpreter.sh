#!/bin/bash
./Ultimate -tc AutomataScriptInterpreter.xml -i "$1"
